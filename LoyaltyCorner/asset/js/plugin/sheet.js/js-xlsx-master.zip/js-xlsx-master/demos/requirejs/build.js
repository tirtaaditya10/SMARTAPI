/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
({
	baseUrl: ".",
	name: "app",
	paths: {
		xlsx: "xlsx.full.min"
	},
	out: "app-built.js"
})
