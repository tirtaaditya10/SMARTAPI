import bottom from './bottom';
import left from './left';
import noBorders from './noBorders';
import right from './right';
import top from './top';

export {
  bottom,
  left,
  noBorders,
  right,
  top
};
