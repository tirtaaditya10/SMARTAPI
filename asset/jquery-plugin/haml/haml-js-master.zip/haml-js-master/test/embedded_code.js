{
  locals: {
    chapter: {name: "Ninja", page: 42},
    name: "Tim",
    id: 42
  }
}