{
  locals: {
    print_date: function () {
      return 'January 1, 2009';
    },
    current_user: {
      address: "Richardson, TX",
      email: "tim@creationix.com",
      bio: "Experienced software professional..."
    }
  }
}