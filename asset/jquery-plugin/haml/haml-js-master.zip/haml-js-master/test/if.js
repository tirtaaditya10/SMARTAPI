{
  locals: {
    numbers: {
      first: {
        one: {
          red: {
            a: "A"
          },
          orange: {
            b: "B"
          },
          yellow: {
            c: "C"
          },
          green: {
            d: "D"
          }
        }
      },
      second: {
        two: {
          blue: {
            e: "E"
          },
          indigo: {
            f: "F"
          },
          violet: {
            g: "G"
          },
          black: {
            h: "H"
          }
        }
      },
      third: {
        three: {
          grey: {
            i: "I"
          },
          white: {
            j: "J"
          },
          pink: {
            k: "K"
          },
          brown: {
            l: "L"
          }
        }
      }
    }
  }
}