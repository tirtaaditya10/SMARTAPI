{
  context: {
    name: "Frank"
  },
  locals: {
    items: [1,2,3]
  }
}