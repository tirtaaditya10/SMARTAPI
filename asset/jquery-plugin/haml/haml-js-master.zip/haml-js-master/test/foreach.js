{
  locals: {
    colors: ["#f80", "#08f", "#4f4"],
    name: "My Rainbow",
    data: [
      {name: "Tim Caswell", age: 27},
      {name: "John Smith", age: 107},
    ]
  }
}