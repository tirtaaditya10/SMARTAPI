export default {
  base: {
    preventDefault: 'auto',
    deltaSource   : 'page',
  },

  perAction: {
    enabled     : false,
    origin: { x: 0, y: 0 },
  },
};
