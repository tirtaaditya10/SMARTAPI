require('babel-register')({
  babelrc: false,
  ...require('./.babelrc'),
});
