---
title: getSelectedNodes
name: multiple-selection-get-selected-nodes
---

Return a list of selected nodes.

{% highlight js %}
var nodes = $('#tree1').tree('getSelectedNodes');
{% endhighlight %}
