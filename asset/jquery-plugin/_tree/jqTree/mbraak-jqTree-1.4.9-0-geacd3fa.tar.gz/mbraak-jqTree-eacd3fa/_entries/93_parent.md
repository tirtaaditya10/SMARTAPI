---
title: parent
name: node-functions-parent
---

You can access the parent of a node using the **parent** property.

{% highlight js %}
var parent_node = node.parent;
{% endhighlight %}
